package com.producerdemo.kafkaproducerdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaProducerDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
