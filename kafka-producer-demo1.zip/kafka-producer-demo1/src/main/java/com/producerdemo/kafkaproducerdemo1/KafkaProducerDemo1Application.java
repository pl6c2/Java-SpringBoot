package com.producerdemo.kafkaproducerdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaProducerDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(KafkaProducerDemo1Application.class, args);
	}

}
